use garden;

select IDZamowienia,DataZamowienia
from zamowienia
where not ((DataZamowienia='20100130' and IDZamowienia>11100) or KosztWysylki between 3 and 11)
