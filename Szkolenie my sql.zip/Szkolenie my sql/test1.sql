use sklep;

select imie,nazwisko,data_ur,miasto
from klient;
	