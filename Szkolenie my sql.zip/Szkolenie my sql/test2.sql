use sklep;

select zakup.nrfaktury,zakup.data_wyst,
klient.imie,klient.nazwisko,
produkt.nazwa_prod,
round(produkt.cena_prod*zakup.liczba_sztuk,2) as 'do zapłaty'
from zakup join klient
on zakup.idklienta = klient.idklienta
join produkt
on zakup.idtowaru = produkt.idproduktu