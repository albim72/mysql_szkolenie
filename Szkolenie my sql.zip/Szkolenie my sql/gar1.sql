use garden;

select IDProduktu, CenaJednostkowa
from produkty 
where CenaJednostkowa in(10,4.5,7);

select IDProduktu, CenaJednostkowa
from produkty
where CenaJednostkowa between 15 and 33;