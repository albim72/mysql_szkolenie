use garden;
select Imie,Nazwisko
from pracownicy
where Nazwisko Like 'O%n';