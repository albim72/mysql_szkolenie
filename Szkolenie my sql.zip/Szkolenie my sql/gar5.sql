use garden;

select z.IDZamowienia, p.Imie, p.Nazwisko
from zamowienia z join pracownicy p
on z.PrzedstKonta = p.IDPracownika;
