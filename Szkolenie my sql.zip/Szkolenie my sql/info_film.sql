use filmy;

select f.tytul,f.rok_prod,f.czas_trwania,
g.nazwa_gat, k.nazwa_kraju, r.imie, r.nazwisko,
kr.nazwa_kraju as 'kraj reżysera'
from film f join gatunek g
on f.idgatunku = g.idgatunku
join kraj k
on f.id_kraju = k.idkraju
join rezyser r
on f.idrezysera = r.idrezysera
join kraj kr
on r.idkraju = k.idkraju