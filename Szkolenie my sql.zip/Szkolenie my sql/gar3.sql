use garden;

select IDProduktu,NazwaProduktu
from produkty
where IDKategorii in (8,11)
and not IDDostawcy = 3
and CenaJednostkowa between 4 and 14
and NazwaProduktu like 'Lawn%';